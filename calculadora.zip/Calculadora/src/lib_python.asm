; ============================================
; lib_python.asm
; Funciones exportadas para la interfaz Python
; Sin buffer, sin print_string, sin dependencias
; Convención C x86-64: RDI=arg1, RSI=arg2 → RAX=resultado
; ============================================

section .text

; ============================================
; ARITMÉTICA
; ============================================

global asmSuma
asmSuma:
    mov rax, rdi
    add rax, rsi
    ret

global asmResta
asmResta:
    mov rax, rdi
    sub rax, rsi
    ret

global asmMultiplicacion
asmMultiplicacion:
    mov rax, rdi
    imul rax, rsi
    ret

global asmDivision
asmDivision:
    cmp rsi, 0
    je .error
    mov rax, rdi
    xor rdx, rdx
    idiv rsi            ; RAX = cociente
    ret
.error:
    mov rax, -1
    ret

; ============================================
; LÓGICA (4 bits)
; ============================================

global asmAnd
asmAnd:
    mov rax, rdi
    and rax, rsi
    and rax, 0xF
    ret

global asmOr
asmOr:
    mov rax, rdi
    or  rax, rsi
    and rax, 0xF
    ret

global asmXor
asmXor:
    mov rax, rdi
    xor rax, rsi
    and rax, 0xF
    ret

global asmNot
asmNot:
    mov rax, rdi
    not rax
    and rax, 0xF
    ret

; ============================================
; CONVERSIÓN: Binario (8 bits) → número
; Entrada : RDI = char* ej: "10101010\n"
; Salida  : RAX = 0..255 o -1 si error
; ============================================

global asmBinToNum
asmBinToNum:
    push rbx
    push rcx
    mov rsi, rdi        ; RDI → RSI para leer bytes
    xor rax, rax
    xor rbx, rbx        ; índice

.bin_loop:
    movzx rcx, byte [rsi + rbx]
    cmp cl, 10          ; \n = fin
    je  .bin_check
    cmp cl, 0           ; null = fin
    je  .bin_check
    cmp cl, '0'
    je  .bin_0
    cmp cl, '1'
    je  .bin_1
    jmp .bin_err        ; carácter inválido

.bin_0:
    shl rax, 1
    jmp .bin_next

.bin_1:
    shl rax, 1
    or  rax, 1

.bin_next:
    inc rbx
    cmp rbx, 8
    jg  .bin_err        ; más de 8 dígitos
    jmp .bin_loop

.bin_check:
    cmp rbx, 8          ; exactamente 8 dígitos
    jne .bin_err
    pop rcx
    pop rbx
    ret

.bin_err:
    mov rax, -1
    pop rcx
    pop rbx
    ret

; ============================================
; CONVERSIÓN: Hexadecimal (2 dígitos) → número
; Entrada : RDI = char* ej: "AA\n"
; Salida  : RAX = 0..255 o -1 si error
; ============================================

global asmHexToNum
asmHexToNum:
    push rbx
    push rcx
    mov rsi, rdi        ; RDI → RSI
    xor rax, rax
    xor rbx, rbx        ; índice

.hex_loop:
    movzx rcx, byte [rsi + rbx]
    cmp cl, 10          ; \n = fin
    je  .hex_check
    cmp cl, 0           ; null = fin
    je  .hex_check

    ; shift DESPUÉS de verificar fin (fix del bug original)
    shl rax, 4

    cmp cl, '0'
    jl  .hex_err
    cmp cl, '9'
    jle .hex_digit
    cmp cl, 'A'
    jl  .hex_err
    cmp cl, 'F'
    jle .hex_upper
    cmp cl, 'a'
    jl  .hex_err
    cmp cl, 'f'
    jle .hex_lower
    jmp .hex_err

.hex_digit:
    sub cl, '0'
    movzx rcx, cl
    or  rax, rcx
    jmp .hex_next

.hex_upper:
    sub cl, 'A'
    add cl, 10
    movzx rcx, cl
    or  rax, rcx
    jmp .hex_next

.hex_lower:
    sub cl, 'a'
    add cl, 10
    movzx rcx, cl
    or  rax, rcx

.hex_next:
    inc rbx
    cmp rbx, 2
    jg  .hex_err        ; más de 2 dígitos
    jmp .hex_loop

.hex_check:
    cmp rbx, 2          ; exactamente 2 dígitos
    jne .hex_err
    pop rcx
    pop rbx
    ret

.hex_err:
    mov rax, -1
    pop rcx
    pop rbx
    ret